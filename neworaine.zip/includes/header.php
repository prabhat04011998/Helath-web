<div class="birdseye-header">
    <div class="nav-wrap">
        <div class="container">
            <div class="logo">
                <span class="wsite-logo">
                    <a href="index.php">
                        <img src="images/logo.png" alt="">
                    </a>
                </span>
            </div>
            <div class="nav desktop-nav">
                <ul class="wsite-menu-default">
                    <li id="pg571061010268150622" class="wsite-menu-item-wrap">
                        <a href="index.php" class="wsite-menu-item">Home</a>
                    </li>
                    <li id="pg282139797871367840" class="wsite-menu-item-wrap">
                        <a href="mask.php" class="wsite-menu-item">Masks</a>
                    </li>
                    <li id="pg282139797871367840" class="wsite-menu-item-wrap">
                        <a href="thermometer.php" class="wsite-menu-item">IR Thermometer</a>
                    </li>
                    <li id="pg393564071576403038" class="wsite-menu-item-wrap">
                        <a href="about-us.php" class="wsite-menu-item">About</a>
                    </li>
                    
                    <li id="pg389626856345982332" class="wsite-menu-item-wrap">
                        <a href="contact.php" class="wsite-menu-item">Contact</a>
                    </li>
                </ul>
            </div>
            <a class="hamburger" aria-label="Menu" href="#"><span></span></a>
        </div>
    </div>
</div>