<div class="footer-wrap">
        <div class="footer">
			<div class='wsite-elements wsite-footer'>
				<div>
					<div class="wsite-multicol">
						<div class="wsite-multicol-table-wrap" style="margin:0 -25px;">
							<table class="wsite-multicol-table">
								<tbody class="wsite-multicol-tbody">
									<tr class="wsite-multicol-tr">
										<td class="wsite-multicol-col" style="width:14.640059641065%; padding:0 25px;">
											<h2 class="wsite-content-title" style="text-align:left;"><font size="4">Registered Address</font></h2>
											<div class="paragraph" style="text-align:left;"><span style="color:rgb(153, 153, 153)">78-79, 3rd Floor, Shiva Arcade, Mayur Vihar Phase 1, New Delhi - 110091</span><br />&#8203;<br /></div>
										</td>
										<td class="wsite-multicol-col" style="width:16.717365400946%; padding:0 25px;">
											<h2 class="wsite-content-title" style="text-align:left;"><font size="4">Corporate Office</font></h2>
											<div class="paragraph" style="text-align:left;"><span style="color:rgb(153, 153, 153)">C-26, Sector 7, Noida - 201 301</span><br />&#8203;<br /></div>
										</td>
										<td class="wsite-multicol-col" style="width:68.642574957988%; padding:0 25px;">
											<div>
												<div class="wsite-multicol">
													<div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
														<table class="wsite-multicol-table">
															<tbody class="wsite-multicol-tbody">
																<tr class="wsite-multicol-tr">
																	<td class="wsite-multicol-col" style="width:58.395245170877%; padding:0 15px;">
																		<h2 class="wsite-content-title" style="text-align:left;"><font size="4">Factory</font></h2>

<div class="paragraph" style="text-align:left;"><span style="color:rgb(153, 153, 153)">Plot 18, Sector 18, Gurugram</span><br /><br /></div>


					
				</td>				<td class="wsite-multicol-col" style="width:41.604754829123%; padding:0 15px;">
					
						

<div class="wsite-spacer" style="height:74px;"></div>

<div style="text-align:right;"><div style="height:10px;overflow:hidden"></div>
<span class="wsite-social wsite-social-default"><a class='first-child wsite-social-item wsite-social-facebook' href='https://www.facebook.com' target='_blank' alt='Facebook'><span class='wsite-social-item-inner'></span></a><a class='wsite-social-item wsite-social-twitter' href='https://twitter.com' target='_blank' alt='Twitter'><span class='wsite-social-item-inner'></span></a><a class='last-child wsite-social-item wsite-social-instagram' href='https://www.instagram.com' target='_blank' alt='Instagram'><span class='wsite-social-item-inner'></span></a></span>
<div style="height:0px;overflow:hidden"></div></div>

<div class="wsite-spacer" style="height:61px;"></div>


					
				</td>			</tr>
		</tbody>
	</table>
</div></div></div>


					
				</td>			</tr>
		</tbody>
	</table>
</div></div></div></div></div>
    </div><!-- end footer-wrap -->
    

    <div class="container">
		<p style="text-align:center">Developed by Onion Rings Technologies</p>
	</div>