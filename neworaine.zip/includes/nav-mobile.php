<div id="navMobile" class="nav mobile-nav">
    <a class="hamburger" aria-label="Menu" href="#"><span></span></a>
    <ul class="wsite-menu-default">
    		<li id="active" class="wsite-menu-item-wrap">
    			<a
    						href="index.html"
    				class="wsite-menu-item"
    				>
    				Home
    			</a>
    			
    		</li>
    		<li id="pg282139797871367840" class="wsite-menu-item-wrap">
    			<a
    						href="shop.html"
    				class="wsite-menu-item"
    				>
    				Shop
    			</a>
    			
    		</li>
    		<li id="pg393564071576403038" class="wsite-menu-item-wrap">
    			<a
    						href="about.html"
    				class="wsite-menu-item"
    				>
    				About
    			</a>
    			
    		</li>
    		<li id="pg522078419655760682" class="wsite-menu-item-wrap">
    			<a
    						href="blog.html"
    				class="wsite-menu-item"
    				>
    				Blog
    			</a>
    			
    		</li>
    		<li id="pg389626856345982332" class="wsite-menu-item-wrap">
    			<a
    						href="contact.html"
    				class="wsite-menu-item"
    				>
    				Contact
    			</a>
    			
    		</li>
    </ul>
  </div>