<!DOCTYPE html>
<html lang="en">
	
<head>
		<script src="gdpr/gdprscript2170.js?buildTime=1589934640&amp;hasRemindMe=true&amp;stealth=false"></script>
		<title>Massco</title><meta property="og:site_name" content="Loveseat" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />

		
		<link id="wsite-base-style" rel="stylesheet" type="text/css" href="css/sites1148.css" />
		<link rel="stylesheet" type="text/css" href="css/fancyboxf948.css" />
		<link rel="stylesheet" type="text/css" href="css/social-icons7e63.css" media="screen,projection" />
		<link rel="stylesheet" type="text/css" href="css/main_stylee58b.css" title="wsite-theme-css" />
		<link href='css/css30e8.css?family=Montserrat:400,700&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css' />

		<link href='css/css30e8.css?family=Montserrat:400,700&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css' />
		<link rel="stylesheet" href="css/home.css">
<style type='text/css'>#wsite-com-product-images .wsite-imageaspectratio-image-height, .wsite-com-category-product-image-height.wsite-imageaspectratio-image-height, .wsite-product .wsite-imageaspectratio-image-height, .wsite-com-category-product-featured-image-height.wsite-imageaspectratio-image-height { margin-bottom: 100% !important } .wsite-com-category-product-group .wsite-com-column { width: 33.33% !important } .wsite-com-category-product-featured-group .wsite-com-column { width: 25.00% !important } .wsite-com-category-subcategory-group .wsite-com-column { width: 33.33% !important } </style>
		<script src='files/templateArtifactse58b.js?1583876865'></script>
<script>
var STATIC_BASE = 'http://cdn1.editmysite.com/';
var ASSETS_BASE = 'http://cdn2.editmysite.com/';
var STYLE_PREFIX = 'wsite';
</script>
<script src='js/jquery.min.js'></script>

<script type="text/javascript" src="js/stl15a6.js"></script>
<script src="js/main1148.js"></script>

<script type="text/javascript">
		function initCustomerAccountsModels() {
					(function(){_W.setup_rpc({"url":"\/ajax\/api\/JsonRPC\/CustomerAccounts\/","actions":{"CustomerAccounts":[{"name":"login","len":2,"multiple":false,"standalone":false},{"name":"logout","len":0,"multiple":false,"standalone":false},{"name":"getSessionDetails","len":0,"multiple":false,"standalone":false},{"name":"getAccountDetails","len":0,"multiple":false,"standalone":false},{"name":"getOrders","len":0,"multiple":false,"standalone":false},{"name":"register","len":4,"multiple":false,"standalone":false},{"name":"emailExists","len":1,"multiple":false,"standalone":false},{"name":"passwordReset","len":1,"multiple":false,"standalone":false},{"name":"passwordUpdate","len":3,"multiple":false,"standalone":false},{"name":"validateSession","len":1,"multiple":false,"standalone":false}]},"namespace":"_W.CustomerAccounts.RPC"});
_W.setup_model_rpc({"rpc_namespace":"_W.CustomerAccounts.RPC","model_namespace":"_W.CustomerAccounts.BackboneModelData","collection_namespace":"_W.CustomerAccounts.BackboneCollectionData","bootstrap_namespace":"_W.CustomerAccounts.BackboneBootstrap","models":{"CustomerAccounts":{"_class":"CustomerAccounts.Model.CustomerAccounts","defaults":null,"validation":null,"types":null,"idAttribute":null,"keydefs":null}},"collections":{"CustomerAccounts":{"_class":"CustomerAccounts.Collection.CustomerAccounts"}},"bootstrap":[]});
})();
		}
		if(document.createEvent && document.addEventListener) {
			var initEvt = document.createEvent('Event');
			initEvt.initEvent('customerAccountsModelsInitialized', true, false);
			document.dispatchEvent(initEvt);
		} else if(document.documentElement.initCustomerAccountsModels === 0){
			document.documentElement.initCustomerAccountsModels++
		}
		</script>
		<script type="text/javascript"> _W = _W || {}; _W.securePrefix='loveseat.templates.editmysite.com'; </script><script>_W = _W || {};
			_W.customerLocale = "en_US";
			_W.storeName = null;
			_W.storeCountry = "US";
			_W.storeCurrency = "USD";
			_W.storeEuPrivacyPolicyUrl = "";
			com_currentSite = "319825474716943932";
			com_userID = "89179606";</script><script type="text/javascript">
								_W = _W || {};
								_W.Commerce = _W.Commerce || {};
								_W.Commerce.hasCart = false;
							</script><script> base_context='Site'; base_name='_W'; ASSETS_BASE='cdn2.editmysite.com'; buildTime='1583863656'</script>

<script>function initCommerceModels() { (function(){_W.setup_rpc({"url":"\/ajax\/api\/JsonRPC\/Commerce\/","actions":{"ABTest":[{"name":"getTestsForVisitor","len":0,"multiple":false,"standalone":false},{"name":"segment","len":1,"multiple":false,"standalone":false}],"Category":[{"name":"generateProductList","len":3,"multiple":false,"standalone":false},{"name":"generateMobileProductList","len":2,"multiple":false,"standalone":false},{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"Checkout":[{"name":"getOrderByToken","len":1,"multiple":false,"standalone":false},{"name":"getMiniCart","len":0,"multiple":false,"standalone":false},{"name":"getCheckoutUrl","len":0,"multiple":false,"standalone":false},{"name":"initializeCheckoutSession","len":0,"multiple":false,"standalone":false},{"name":"getPayPalNotifyUrl","len":0,"multiple":false,"standalone":false},{"name":"getAuthorizeNetFingerprint","len":0,"multiple":false,"standalone":false},{"name":"getPayPalEcoUrl","len":0,"multiple":false,"standalone":false},{"name":"processPayPalCheckoutDetails","len":0,"multiple":false,"standalone":false},{"name":"getCurrentOrder","len":0,"multiple":false,"standalone":false},{"name":"resetCart","len":0,"multiple":false,"standalone":false},{"name":"getSquareStoreConfig","len":0,"multiple":false,"standalone":false},{"name":"logErrorOnValidOrderCase","len":1,"multiple":false,"standalone":false},{"name":"getShoppingCart","len":0,"multiple":false,"standalone":false},{"name":"addItemToCart","len":2,"multiple":false,"standalone":false},{"name":"addItem","len":3,"multiple":false,"standalone":false},{"name":"getInventory","len":1,"multiple":false,"standalone":false},{"name":"updateItemQuantity","len":3,"multiple":false,"standalone":false},{"name":"updateItemQuantityV2","len":2,"multiple":false,"standalone":false},{"name":"hasCouponsAvailable","len":0,"multiple":false,"standalone":false},{"name":"applyCoupon","len":1,"multiple":false,"standalone":false},{"name":"removeCoupon","len":1,"multiple":false,"standalone":false},{"name":"isShippable","len":1,"multiple":false,"standalone":false},{"name":"checkCart","len":2,"multiple":false,"standalone":false},{"name":"generateProductList","len":3,"multiple":false,"standalone":false},{"name":"shouldSeePaymentRequestAPI","len":0,"multiple":false,"standalone":false},{"name":"shouldSeeApplePay","len":0,"multiple":false,"standalone":false},{"name":"addTipAmount","len":1,"multiple":false,"standalone":false},{"name":"toggleTextAlert","len":3,"multiple":false,"standalone":false},{"name":"addTipPercentage","len":1,"multiple":false,"standalone":false}],"CustomerAddress":[{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"Customer":[{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"Log":[{"name":"notice","len":2,"multiple":false,"standalone":false},{"name":"error","len":2,"multiple":false,"standalone":false}],"OrderBilling":[{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"OrderItem":[{"name":"updateQuantity","len":1,"multiple":false,"standalone":false},{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"Order":[{"name":"getHash","len":0,"multiple":false,"standalone":false},{"name":"fetchCorrectedCart","len":0,"multiple":false,"standalone":false},{"name":"getAvailablePickupTime","len":2,"multiple":false,"standalone":false},{"name":"updatePickupTime","len":4,"multiple":false,"standalone":false},{"name":"updatePaymentMethod","len":1,"multiple":false,"standalone":false},{"name":"updateShippingMethod","len":1,"multiple":false,"standalone":false},{"name":"updateOrderBilling","len":1,"multiple":false,"standalone":false},{"name":"updateOrderNotes","len":0,"multiple":false,"standalone":false},{"name":"updateCustomer","len":2,"multiple":false,"standalone":false},{"name":"addGiftCard","len":1,"multiple":false,"standalone":false},{"name":"removeGiftCard","len":1,"multiple":false,"standalone":false},{"name":"checkout","len":3,"multiple":false,"standalone":false},{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"OrderShipment":[{"name":"updateFulfillment","len":1,"multiple":false,"standalone":false},{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"Product":[{"name":"isInStock","len":2,"multiple":false,"standalone":false},{"name":"readFullText","len":1,"multiple":false,"standalone":false},{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"ShippingRate":[{"name":"create","len":1,"multiple":false,"standalone":false},{"name":"readOne","len":1,"multiple":false,"standalone":false},{"name":"readMany","len":1,"multiple":false,"standalone":false},{"name":"update","len":1,"multiple":false,"standalone":false},{"name":"patch","len":1,"multiple":false,"standalone":false},{"name":"destroy","len":1,"multiple":false,"standalone":false}],"StoredPayment":[{"name":"verify","len":1,"multiple":false,"standalone":false},{"name":"verifyConfirm","len":2,"multiple":false,"standalone":false},{"name":"deleteAll","len":1,"multiple":false,"standalone":false}]},"namespace":"_W.Commerce.RPC"});
_W.setup_model_rpc({"rpc_namespace":"_W.Commerce.RPC","model_namespace":"_W.Commerce.BackboneModelData","collection_namespace":"_W.Commerce.BackboneCollectionData","bootstrap_namespace":"_W.Commerce.BackboneBootstrap","models":{"ABTest":{"_class":"Commerce.Model.ABTest","defaults":null,"validation":null,"types":null,"idAttribute":null,"keydefs":null},"Category":{"_class":"Commerce.Model.Category","defaults":{"shown_in_storefront":false,"site_link":null,"product_count":null,"published":true,"name":"","page_layout":"no-header","page_title":null,"page_description":null,"show_featured_products":true,"show_sub_categories":true,"children_collapsed":false,"hide_from_parent":false,"parent_category_id":null,"category_order":null,"image_order":null,"permalink":null,"product_ids":null,"preferred_order_product_ids":null,"coupon_ids":null,"is_user_defined":"true","og_title":null,"og_description":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"shown_in_storefront":null,"site_link":null,"product_count":null,"site_category_id":null,"published":null,"name":{"required":true},"page_layout":null,"page_title":null,"page_description":null,"show_featured_products":null,"show_sub_categories":null,"children_collapsed":null,"hide_from_parent":null,"parent_category_id":null,"category_order":null,"image_order":null,"permalink":{"pattern":"^[\\w\\\/.-]*$","required":false},"product_ids":null,"preferred_order_product_ids":null,"coupon_ids":null,"is_user_defined":null,"og_title":null,"og_description":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"shown_in_storefront":"boolean","site_link":"string","product_count":null,"site_category_id":"string","published":"boolean","name":"string","page_layout":"string","page_title":"string","page_description":"string","show_featured_products":"boolean","show_sub_categories":"boolean","children_collapsed":"boolean","hide_from_parent":"boolean","parent_category_id":null,"category_order":"integer","image_order":"json","permalink":"string","product_ids":"json","preferred_order_product_ids":"json","coupon_ids":"json","is_user_defined":"boolean","og_title":"string","og_description":"string","uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_category_id","keydefs":{"PRIMARY":["owner_id","site_id","site_category_id"],"uuid_index":["id"]},"relations":[{"type":"HasMany","key":"images","foreignKey":["owner_id","site_id","site_category_id"],"parse":true,"relatedModel":"CategoryImage","reverseRelation":{"key":null,"includeInJSON":false}}]},"Checkout":{"_class":"Commerce.Model.Checkout","defaults":null,"validation":null,"types":null,"idAttribute":null,"keydefs":null},"CustomerAddress":{"_class":"Commerce.Model.CustomerAddress","defaults":{"site_customer_id":null,"label":"","is_copy":false,"name_first":null,"name_last":null,"business_name":"","street":"","street2":null,"postal_code":"","city":"","region":"","country":"","phone_country_code":"","phone":null,"changedAddressComponents":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"site_customer_id":null,"site_customer_address_id":null,"label":{"required":true},"is_copy":null,"name_first":null,"name_last":null,"business_name":null,"street":null,"street2":null,"postal_code":null,"city":null,"region":null,"country":null,"phone_country_code":null,"phone":null,"changedAddressComponents":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"site_customer_id":"string","site_customer_address_id":"int","label":"string","is_copy":null,"name_first":"string","name_last":"string","business_name":"string","street":"string","street2":"string","postal_code":"string","city":"string","region":"string","country":"string","phone_country_code":"string","phone":"string","changedAddressComponents":"json","uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_customer_address_id","keydefs":{"PRIMARY":["owner_id","site_id","site_customer_id","site_customer_address_id"],"uuid_index":["id"],"address":["owner_id","site_id","deleted","country","region","city"],"address_name":["owner_id","site_id","deleted","label"]}},"Customer":{"_class":"Commerce.Model.Customer","defaults":{"name_prefix":null,"name_first":null,"name_last":null,"name_suffix":null,"email":null,"business_name":null,"home_phone":null,"work_phone":null,"pickup_phone":null,"is_marketing_updates_subscribed":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"site_customer_id":null,"name_prefix":null,"name_first":null,"name_last":null,"name_suffix":null,"email":{"email":null,"required":false},"business_name":null,"home_phone":{"minlength":"7","required":false},"work_phone":{"minlength":"7","required":true},"pickup_phone":{"minlength":"7","required":true},"is_marketing_updates_subscribed":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"site_customer_id":"string","name_prefix":"string","name_first":"string","name_last":"string","name_suffix":"string","email":"string","business_name":"string","home_phone":"string","work_phone":"string","pickup_phone":"string","is_marketing_updates_subscribed":"boolean","uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_customer_id","keydefs":{"PRIMARY":["owner_id","site_id","site_customer_id"],"uuid_index":["id"],"lastname":["deleted","site_id","name_last"],"email":["deleted","site_id","email"],"business":["deleted","site_id","business_name"],"idx_owner_site_account":["owner_id","site_id","site_account_id"]},"relations":[{"type":"HasMany","key":"addresses","foreignKey":["owner_id","site_id","site_customer_id"],"parse":true,"relatedModel":"CustomerAddress","reverseRelation":{"key":"customer","includeInJSON":false}},{"type":"HasMany","key":"orders","foreignKey":["owner_id","site_id","site_customer_id"],"parse":true,"relatedModel":"Order","reverseRelation":{"key":"original_customer","includeInJSON":false}}]},"Log":{"_class":"Commerce.Model.Log","defaults":null,"validation":null,"types":null,"idAttribute":null,"keydefs":null},"OrderBilling":{"_class":"Commerce.Model.OrderBilling","defaults":{"refundable_amount":null,"site_order_id":null,"gateway":"","site_payment_gateway_id":null,"site_customer_id":"","site_customer_address_id":null,"full_name":null,"email":null,"phone":null,"business_name":null,"street":null,"street2":null,"city":null,"region":null,"country":null,"postal_code":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"refundable_amount":null,"site_order_id":null,"site_order_billing_id":null,"gateway":{"required":true},"site_payment_gateway_id":null,"site_customer_id":{"required":true},"site_customer_address_id":null,"full_name":null,"email":null,"phone":null,"business_name":null,"street":null,"street2":null,"city":null,"region":null,"country":null,"postal_code":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"refundable_amount":"int","site_order_id":"string","site_order_billing_id":"int","gateway":"string","site_payment_gateway_id":"string","site_customer_id":"string","site_customer_address_id":"int","full_name":"string","email":"string","phone":"string","business_name":"string","street":"string","street2":"string","city":"string","region":"string","country":"string","postal_code":"string","uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_order_billing_id","keydefs":{"PRIMARY":["owner_id","site_id","site_order_id","site_order_billing_id"],"uuid_index":["id"]},"relations":[{"type":"HasMany","key":"transactions","foreignKey":["owner_id","site_id","site_order_id","site_order_billing_id"],"parse":true,"relatedModel":"OrderBillingTransaction","reverseRelation":{"key":null,"includeInJSON":false}}]},"OrderItem":{"_class":"Commerce.Model.OrderItem","defaults":{"fulfillment_method":null,"current_price":null,"current_price_subunits":null,"discounted_price":null,"product_url":null,"full_product_url":null,"image_info":null,"track_inventory":null,"sku_uuid":null,"site_order_id":null,"site_product_id":"","site_product_sku_id":0,"name":"","short_description":null,"taxable":null,"quantity":1,"paid":0,"prepared":"0","completed":0,"refunded":0,"cancelled":0,"product_type":null,"download_limit_type":null,"download_units_remaining":null,"measurement_unit_abbreviation":null,"fulfillment_options":null,"buyer_controlled_price":null,"has_buyer_controlled_price":null,"price":null,"sale_price":null,"total_price":0,"modifiers_price":null,"total_modifiers_price":null,"weight":null,"weight_unit":"lb","sku":null,"options":null,"returned":null,"discounts":null,"issued_gift_cards":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"fulfillment_method":null,"current_price":null,"current_price_subunits":null,"discounted_price":null,"product_url":null,"full_product_url":null,"image_info":null,"track_inventory":null,"sku_uuid":null,"site_order_id":null,"site_order_item_id":null,"site_product_id":{"required":true},"site_product_sku_id":{"required":true},"name":null,"short_description":null,"taxable":null,"quantity":null,"paid":null,"prepared":null,"completed":null,"refunded":null,"cancelled":null,"product_type":null,"download_limit_type":null,"download_units_remaining":null,"measurement_unit_abbreviation":null,"fulfillment_options":null,"buyer_controlled_price":{"min":"0","required":false},"has_buyer_controlled_price":null,"price":null,"sale_price":null,"total_price":null,"modifiers_price":null,"total_modifiers_price":null,"weight":null,"weight_unit":null,"sku":null,"options":null,"returned":null,"discounts":null,"issued_gift_cards":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"fulfillment_method":"string","current_price":"decimal","current_price_subunits":"int","discounted_price":"decimal","product_url":"string","full_product_url":"string","image_info":"string","track_inventory":"boolean","sku_uuid":"string","site_order_id":"string","site_order_item_id":"string","site_product_id":"string","site_product_sku_id":"int","name":"string","short_description":"mediumtext","taxable":"int","quantity":"int","paid":"int","prepared":"string","completed":"int","refunded":"int","cancelled":"int","product_type":"string","download_limit_type":"string","download_units_remaining":"int","measurement_unit_abbreviation":"array","fulfillment_options":"array","buyer_controlled_price":"float","has_buyer_controlled_price":"boolean","price":"decimal","sale_price":"decimal","total_price":"decimal","modifiers_price":"decimal","total_modifiers_price":"decimal","weight":"decimal","weight_unit":"string","sku":"string","options":"json","returned":"int","discounts":"json","issued_gift_cards":"json","uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_order_item_id","keydefs":{"PRIMARY":["owner_id","site_id","site_order_id","site_order_item_id"],"uuid_index":["id"]},"relations":[{"type":"HasMany","key":"shipment_items","foreignKey":["owner_id","site_id","site_order_id","site_order_id"],"parse":true,"relatedModel":"OrderShipmentToItem","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"order_item_file","foreignKey":["owner_id","site_id","site_order_id","site_order_item_id"],"parse":true,"relatedModel":"OrderItemFile","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"original_product_sku_file","foreignKey":["owner_id","site_id","site_product_id","site_product_sku_id"],"parse":true,"relatedModel":"ProductSkuFile","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"modifier_selections","foreignKey":["owner_id","site_id","site_order_id","site_order_item_id"],"parse":true,"relatedModel":"OrderItemModifierSelection","reverseRelation":{"key":null,"includeInJSON":false}}]},"Order":{"_class":"Commerce.Model.Order","defaults":{"order_display_status":null,"order_display_type":null,"order_available_actions_list":null,"order_fulfillment_options":null,"order_fulfillment_method":null,"order_fulfillment_methods":null,"is_prepared_enabled":null,"refundable_amount":null,"is_customer_address_required":null,"site_customer_id":null,"order_type":"cart","full_name":null,"is_marketing_updates_subscribed":null,"is_eu_user":null,"order_status":"pending","order_currency":"usd","source":"0","source_site_id":"null","is_text_alerts_enabled":false,"order_item_tax_total":null,"order_gift_card_total":null,"order_tax_total":0,"order_tip_total":0,"auto_calculate_tip_percentage":-1,"order_tip_percentage":null,"order_tax_total_subunits":null,"order_balance_due_total":null,"order_balance_due_total_in_subunits":null,"order_tax_rates":null,"include_taxes_in_price":false,"charge_taxes_on_shipping":false,"order_shipping_total":0,"order_shipping_taxes_total":0,"order_shipping_subtotal":null,"order_shipping_subtotal_subunits":null,"order_shipping_method":null,"order_subtotal":0,"order_discount_total":null,"order_total":0,"token":null,"paypal_token":null,"paypal_payer_id":null,"refunded_amount":0,"order_paid_date":null,"return_inventory_date":null,"cart_hash":null,"gift_cards":null,"contains_download":null,"contains_service":null,"contains_donation":null,"contains_event":null,"contains_membership":null,"contains_simple_digital":null,"contains_physical":null,"contains_food":null,"contains_giftcard":null,"order_shipment_status":null,"contains_physical_or_similar":null,"order_notes":null,"order_transaction_fee":null,"weight":null,"billing_summary":null,"selected_payment_method_uuid":null,"payment_method_verification_uuid":null,"discounts":null,"pickup_locations":null,"store_location_uuid":null,"ordering_site_fulfillment_location":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"order_display_status":null,"order_display_type":null,"order_available_actions_list":null,"order_fulfillment_options":null,"order_fulfillment_method":null,"order_fulfillment_methods":null,"is_prepared_enabled":null,"refundable_amount":null,"is_customer_address_required":null,"site_order_id":null,"site_customer_id":null,"order_type":{"oneOf":["abandoned","order","cart","wishlist"],"required":false},"full_name":null,"is_marketing_updates_subscribed":null,"is_eu_user":null,"order_status":null,"order_currency":null,"source":null,"source_site_id":null,"is_text_alerts_enabled":null,"order_item_tax_total":null,"order_gift_card_total":null,"order_tax_total":null,"order_tip_total":null,"auto_calculate_tip_percentage":null,"order_tip_percentage":null,"order_tax_total_subunits":null,"order_balance_due_total":null,"order_balance_due_total_in_subunits":null,"order_tax_rates":null,"include_taxes_in_price":null,"charge_taxes_on_shipping":null,"order_shipping_total":null,"order_shipping_taxes_total":null,"order_shipping_subtotal":null,"order_shipping_subtotal_subunits":null,"order_shipping_method":null,"order_subtotal":null,"order_discount_total":null,"order_total":null,"token":null,"paypal_token":null,"paypal_payer_id":null,"refunded_amount":null,"order_paid_date":null,"return_inventory_date":null,"cart_hash":null,"gift_cards":null,"contains_download":null,"contains_service":null,"contains_donation":null,"contains_event":null,"contains_membership":null,"contains_simple_digital":null,"contains_physical":null,"contains_food":null,"contains_giftcard":null,"order_shipment_status":null,"contains_physical_or_similar":null,"order_notes":null,"order_transaction_fee":null,"weight":null,"billing_summary":null,"selected_payment_method_uuid":null,"payment_method_verification_uuid":null,"discounts":null,"pickup_locations":null,"store_location_uuid":null,"ordering_site_fulfillment_location":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"order_display_status":"string","order_display_type":"string","order_available_actions_list":"array","order_fulfillment_options":"array","order_fulfillment_method":"string","order_fulfillment_methods":"array","is_prepared_enabled":"boolean","refundable_amount":"decimal","is_customer_address_required":"boolean","site_order_id":"string","site_customer_id":"string","order_type":"string","full_name":"string","is_marketing_updates_subscribed":null,"is_eu_user":null,"order_status":"string","order_currency":"string","source":"string","source_site_id":"string","is_text_alerts_enabled":"boolean","order_item_tax_total":"decimal","order_gift_card_total":"decimal","order_tax_total":"decimal","order_tip_total":"decimal","auto_calculate_tip_percentage":"int","order_tip_percentage":"int","order_tax_total_subunits":"int","order_balance_due_total":"decimal","order_balance_due_total_in_subunits":"int","order_tax_rates":"json","include_taxes_in_price":"boolean","charge_taxes_on_shipping":"boolean","order_shipping_total":"decimal","order_shipping_taxes_total":"decimal","order_shipping_subtotal":"decimal","order_shipping_subtotal_subunits":"int","order_shipping_method":"string","order_subtotal":"decimal","order_discount_total":"decimal","order_total":"decimal","token":"string","paypal_token":"string","paypal_payer_id":"string","refunded_amount":"decimal","order_paid_date":"int","return_inventory_date":"int","cart_hash":"string","gift_cards":"json","contains_download":"boolean","contains_service":"boolean","contains_donation":"boolean","contains_event":"boolean","contains_membership":"boolean","contains_simple_digital":"boolean","contains_physical":"boolean","contains_food":"boolean","contains_giftcard":"boolean","order_shipment_status":"string","contains_physical_or_similar":"boolean","order_notes":"string","order_transaction_fee":"json","weight":null,"billing_summary":"string","selected_payment_method_uuid":"string","payment_method_verification_uuid":"string","discounts":"json","pickup_locations":"array","store_location_uuid":null,"ordering_site_fulfillment_location":null,"uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_order_id","keydefs":{"PRIMARY":["owner_id","site_id","site_order_id"],"token_2":["token"],"uuid_index":["id"],"order_status":["owner_id","site_id","deleted","order_type","order_status"],"customer":["owner_id","site_id","deleted","site_customer_id","order_type","order_status"],"com_order_date":["owner_id","site_id","deleted","order_type","order_paid_date"],"abandoned_cart":["owner_id","site_id","deleted","order_type","created_date","updated_date","abandoned_cart_processed","abandoned_cart_sent_email_id","site_order_id","site_customer_id"],"orders_by_date":["deleted","order_type","updated_date"],"orders_by_source_site":["owner_id","site_id","deleted","order_type","source","source_site_id"]},"relations":[{"type":"HasMany","key":"items","foreignKey":["owner_id","site_id","site_order_id"],"parse":true,"relatedModel":"OrderItem","reverseRelation":{"key":"order","includeInJSON":false}},{"type":"HasMany","key":"shipments","foreignKey":["owner_id","site_id","site_order_id"],"parse":true,"relatedModel":"OrderShipment","reverseRelation":{"key":"order","includeInJSON":false}},{"type":"HasMany","key":"billings","foreignKey":["owner_id","site_id","site_order_id"],"parse":true,"relatedModel":"OrderBilling","reverseRelation":{"key":"order","includeInJSON":false}},{"type":"HasMany","key":"coupons","foreignKey":["owner_id","site_id","site_order_id"],"parse":true,"relatedModel":"OrderCoupon","reverseRelation":{"key":null,"includeInJSON":false}}]},"OrderShipment":{"_class":"Commerce.Model.OrderShipment","defaults":{"site_order_id":null,"type":"quote","site_customer_id":"","site_customer_address_id":0,"shipping_provider":null,"site_shipping_provider_id":null,"shipping_provider_payment":null,"site_shipping_box_id":null,"max_items":null,"max_box_weight":null,"sync_with_square_failed":null,"weight":null,"weight_unit":"lb","height":null,"width":null,"depth":null,"full_name":null,"email":null,"phone":null,"business_name":null,"street":null,"street2":null,"city":null,"region":null,"country":null,"postal_code":null,"site_shipping_price_id":null,"site_shipping_method_id":null,"shipment_tax_total":0,"shipment_tax_rates":null,"selected_shipping_rate_quote":null,"site_store_address_id":null,"pickup_store_address_id":null,"pickup_instructions":null,"pickup_location_display_name":null,"pickup_schedule_type":null,"pickup_prep_time_duration":null,"price":0,"shipment_total":null,"charge_taxes_on_shipping":false,"title":null,"site_shipping_method_type":null,"site_shipping_method_subtype":null,"site_shipping_method_default_rate":null,"site_shipping_method_rates":null,"shipment_date":null,"tracking_number":null,"tracking_url_provider":null,"status":null,"pickup_time":null,"pickup_time_unix":null,"pickup_date":null,"pickup_time_24_hour":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"site_order_id":null,"site_order_shipment_id":null,"type":{"oneOf":["shipment","quote","pickup","manual"],"required":false},"site_customer_id":{"required":true},"site_customer_address_id":{"required":true},"shipping_provider":null,"site_shipping_provider_id":null,"shipping_provider_payment":null,"site_shipping_box_id":null,"max_items":null,"max_box_weight":null,"sync_with_square_failed":null,"weight":null,"weight_unit":null,"height":null,"width":null,"depth":null,"full_name":null,"email":null,"phone":null,"business_name":null,"street":null,"street2":null,"city":null,"region":null,"country":null,"postal_code":null,"site_shipping_price_id":null,"site_shipping_method_id":null,"shipment_tax_total":null,"shipment_tax_rates":null,"selected_shipping_rate_quote":null,"site_store_address_id":null,"pickup_store_address_id":null,"pickup_instructions":null,"pickup_location_display_name":null,"pickup_schedule_type":null,"pickup_prep_time_duration":null,"price":null,"shipment_total":null,"charge_taxes_on_shipping":null,"title":null,"site_shipping_method_type":null,"site_shipping_method_subtype":null,"site_shipping_method_default_rate":null,"site_shipping_method_rates":null,"shipment_date":null,"tracking_number":null,"tracking_url_provider":null,"status":null,"pickup_time":null,"pickup_time_unix":null,"pickup_date":null,"pickup_time_24_hour":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"site_order_id":"string","site_order_shipment_id":"int","type":"string","site_customer_id":"string","site_customer_address_id":"int","shipping_provider":"string","site_shipping_provider_id":"int","shipping_provider_payment":"json","site_shipping_box_id":null,"max_items":null,"max_box_weight":null,"sync_with_square_failed":"boolean","weight":"decimal","weight_unit":"string","height":"decimal","width":"decimal","depth":"decimal","full_name":"string","email":"string","phone":"string","business_name":"string","street":"string","street2":"string","city":"string","region":"string","country":"string","postal_code":"string","site_shipping_price_id":"string","site_shipping_method_id":null,"shipment_tax_total":"decimal","shipment_tax_rates":"json","selected_shipping_rate_quote":"string","site_store_address_id":"string","pickup_store_address_id":"int","pickup_instructions":"string","pickup_location_display_name":"string","pickup_schedule_type":"string","pickup_prep_time_duration":"string","price":"decimal","shipment_total":"decimal","charge_taxes_on_shipping":"boolean","title":"string","site_shipping_method_type":null,"site_shipping_method_subtype":null,"site_shipping_method_default_rate":null,"site_shipping_method_rates":null,"shipment_date":null,"tracking_number":null,"tracking_url_provider":null,"status":"string","pickup_time":"string","pickup_time_unix":"int","pickup_date":"string","pickup_time_24_hour":"string","uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_order_shipment_id","keydefs":{"PRIMARY":["owner_id","site_id","site_order_id","site_order_shipment_id"],"uuid_index":["id"],"site_store_address_id":["site_store_address_id"],"shipping_label_purchase_batch_index":["owner_id","site_id","site_shipping_label_purchase_batch_id"]},"relations":[{"type":"HasMany","key":"original_box","foreignKey":["owner_id","site_id","site_shipping_box_id"],"parse":true,"relatedModel":"ShippingBox","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"transactions","foreignKey":["owner_id","site_id","site_order_id","site_order_shipment_id"],"parse":true,"relatedModel":"OrderShipmentTransaction","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"original_shipment_rate","foreignKey":["owner_id","site_id","site_shipping_price_id"],"parse":true,"relatedModel":"ShippingRate","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"original_shipping_method","foreignKey":["owner_id","site_id","site_shipping_method_id"],"parse":true,"relatedModel":"ShippingMethod","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"items","foreignKey":["owner_id","site_id","site_order_id","site_order_shipment_id"],"parse":true,"relatedModel":"OrderShipmentToItem","reverseRelation":{"key":null,"includeInJSON":false}}]},"Product":{"_class":"Commerce.Model.Product","defaults":{"site_link":null,"mli_price_inventory_generated":null,"site_shipping_box_id":null,"name":null,"short_description":null,"variation_type":"1","seo_page_title":null,"seo_page_description":null,"published":true,"price_low_all_locations":null,"price_high_all_locations":null,"visibility":"visible","track_inventory":false,"taxable":true,"option_sets":null,"image_order":null,"product_type_details":null,"product_type":"physical","permalink":null,"price_low":null,"price_high":null,"sale_price_low":null,"sale_price_high":null,"inventory":null,"inventory_low":null,"average_rating":null,"average_rating_all":null,"all_skus_sale":null,"highest_nonsale":null,"lowest_nonsale":null,"visibility_selector_disabled":null,"min_prep_time":null,"category_ids":null,"coupon_ids":null,"last_catalog_sync":null,"seo_product_image_id":null,"og_title":null,"og_description":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"site_link":null,"site_product_id":null,"mli_price_inventory_generated":null,"site_shipping_box_id":null,"name":null,"short_description":null,"variation_type":{"oneOf":["1","2","3"],"required":false},"seo_page_title":null,"seo_page_description":null,"published":null,"price_low_all_locations":null,"price_high_all_locations":null,"visibility":{"oneOf":["visible","hidden","unavailable"],"required":false},"track_inventory":null,"taxable":null,"option_sets":null,"image_order":null,"product_type_details":null,"product_type":null,"permalink":{"pattern":"^[\\w\\\/.-]*$","required":false},"price_low":null,"price_high":null,"sale_price_low":null,"sale_price_high":null,"inventory":null,"inventory_low":null,"average_rating":null,"average_rating_all":null,"all_skus_sale":null,"highest_nonsale":null,"lowest_nonsale":null,"visibility_selector_disabled":null,"min_prep_time":null,"category_ids":null,"coupon_ids":null,"last_catalog_sync":null,"seo_product_image_id":null,"og_title":null,"og_description":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"site_link":"string","site_product_id":"string","mli_price_inventory_generated":"decimal","site_shipping_box_id":"integer","name":"string","short_description":"string","variation_type":"string","seo_page_title":"string","seo_page_description":"string","published":"boolean","price_low_all_locations":"decimal","price_high_all_locations":"decimal","visibility":"string","track_inventory":"boolean","taxable":"boolean","option_sets":"array","image_order":"json","product_type_details":"json","product_type":"string","permalink":"string","price_low":"decimal","price_high":"decimal","sale_price_low":"decimal","sale_price_high":"decimal","inventory":"string","inventory_low":"integer","average_rating":"decimal","average_rating_all":"decimal","all_skus_sale":"boolean","highest_nonsale":"decimal","lowest_nonsale":"decimal","visibility_selector_disabled":"boolean","min_prep_time":"integer","category_ids":"json","coupon_ids":"json","last_catalog_sync":"int","seo_product_image_id":"int","og_title":"string","og_description":"string","uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_product_id","keydefs":{"PRIMARY":["owner_id","site_id","site_product_id"],"uuid_index":["id"],"manufacturer":["owner_id","site_product_id","site_manufacturer_id"],"created_date":["owner_id","site_id","deleted","created_date"],"updated_date":["owner_id","site_id","deleted","updated_date"],"com_product_average_rating_owner_id_site_id_index":["average_rating","owner_id","site_id"],"com_product_average_rating_all_owner_id_site_id_index":["average_rating_all","owner_id","site_id"],"product_popularity_score":["owner_id","site_id","popularity_score"]},"relations":[{"type":"HasMany","key":"shipping_box","foreignKey":["owner_id","site_id","site_shipping_box_id"],"parse":true,"relatedModel":"ShippingBox","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"modifiers","foreignKey":["owner_id","site_id","site_product_id"],"parse":true,"relatedModel":"ProductModifier","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"skus","foreignKey":["owner_id","site_id","site_product_id"],"parse":true,"relatedModel":"ProductSku","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"images","foreignKey":["owner_id","site_id","site_product_id"],"parse":true,"relatedModel":"ProductImage","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"media_files","foreignKey":["owner_id","site_id","site_product_id"],"parse":true,"relatedModel":"ProductMediaFile","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"manufacturer","foreignKey":["owner_id","site_id"],"parse":true,"relatedModel":"Manufacturer","reverseRelation":{"key":null,"includeInJSON":false}},{"type":"HasMany","key":"options2","foreignKey":["owner_id","site_id","site_product_id"],"parse":true,"relatedModel":"ProductOption","reverseRelation":{"key":null,"includeInJSON":false}}]},"ShippingRate":{"_class":"Commerce.Model.ShippingRate","defaults":{"title":null,"country":null,"type":null,"minimum":0,"maximum":0,"price":0,"coupon_ids":null,"uuid":null,"owner_id":"","site_id":"","created_date":0,"updated_date":0},"validation":{"site_shipping_price_id":null,"title":null,"country":null,"type":{"oneOf":["Price","Weight"],"required":false},"minimum":null,"maximum":null,"price":null,"coupon_ids":null,"uuid":null,"owner_id":{"required":true},"site_id":{"required":true},"created_date":null,"updated_date":null},"types":{"site_shipping_price_id":"int","title":"String","country":"String","type":"String","minimum":"decimal","maximum":"decimal","price":"decimal","coupon_ids":"json","uuid":null,"owner_id":"string","site_id":"string","created_date":"int","updated_date":"int"},"idAttribute":"site_shipping_price_id","keydefs":{"PRIMARY":["owner_id","site_id","site_shipping_price_id"],"uuid_index":["id"]},"relations":[{"type":"HasMany","key":"region_rates","foreignKey":["owner_id","site_id","site_shipping_price_id"],"parse":true,"relatedModel":"ShippingRegionRate","reverseRelation":{"key":null,"includeInJSON":false}}]},"StoredPayment":{"_class":"Commerce.Model.StoredPayment","defaults":null,"validation":null,"types":null,"idAttribute":null,"keydefs":null}},"collections":{"ABTest":{"_class":"Commerce.Collection.ABTest"},"Category":{"_class":"Commerce.Collection.Category"},"Checkout":{"_class":"Commerce.Collection.Checkout"},"CustomerAddress":{"_class":"Commerce.Collection.CustomerAddress"},"Customer":{"_class":"Commerce.Collection.Customer"},"Log":{"_class":"Commerce.Collection.Log"},"OrderBilling":{"_class":"Commerce.Collection.OrderBilling"},"OrderItem":{"_class":"Commerce.Collection.OrderItem"},"Order":{"_class":"Commerce.Collection.Order"},"OrderShipment":{"_class":"Commerce.Collection.OrderShipment"},"Product":{"_class":"Commerce.Collection.Product"},"ShippingRate":{"_class":"Commerce.Collection.ShippingRate"},"StoredPayment":{"_class":"Commerce.Collection.StoredPayment"}},"bootstrap":[]});
})(); }</script>
<script src='../cdn2.editmysite.com/js/site/commerce-core1148.js?buildTime=1583863656'></script>
<script src='../cdn2.editmysite.com/js/site/main-commerce-browse1148.js?buildTime=1583863656'></script><script type="text/javascript">_W.configDomain = "www.weebly.com";</script><script>_W.relinquish && _W.relinquish()</script>
<script type="text/javascript" src="../cdn2.editmysite.com/js/lang/en/stl15a6.js?buildTime=1583863656&amp;"></script><script> _W.themePlugins = [];</script><script type="text/javascript"> _W.recaptchaUrl = "../www.google.com/recaptcha/api.js"; </script><script type="text/javascript">
	
	
	function initFlyouts(){
		initPublishedFlyoutMenus(
			[{"id":"571061010268150622","title":"Home","url":"index.html","target":"","nav_menu":false,"nonclickable":false},{"id":"282139797871367840","title":"Shop","url":"shop.html","target":"","nav_menu":false,"nonclickable":false},{"id":"393564071576403038","title":"About","url":"about.html","target":"","nav_menu":false,"nonclickable":false},{"id":"522078419655760682","title":"Blog","url":"blog.html","target":"","nav_menu":false,"nonclickable":false},{"id":"389626856345982332","title":"Contact","url":"contact.html","target":"","nav_menu":false,"nonclickable":false}],
			"571061010268150622",
			'',
			'active',
			false,
			{"navigation\/item":"<li {{#id}}id=\"{{id}}\"{{\/id}} class=\"wsite-menu-item-wrap\">\n\t<a\n\t\t{{^nonclickable}}\n\t\t\t{{^nav_menu}}\n\t\t\t\thref=\"{{url}}\"\n\t\t\t{{\/nav_menu}}\n\t\t{{\/nonclickable}}\n\t\t{{#target}}\n\t\t\ttarget=\"{{target}}\"\n\t\t{{\/target}}\n\t\t{{#membership_required}}\n\t\t\tdata-membership-required=\"{{.}}\"\n\t\t{{\/membership_required}}\n\t\tclass=\"wsite-menu-item\"\n\t\t>\n\t\t{{{title_html}}}\n\t<\/a>\n\t{{#has_children}}{{> navigation\/flyout\/list}}{{\/has_children}}\n<\/li>\n","navigation\/flyout\/list":"<div class=\"wsite-menu-wrap\" style=\"display:none\">\n\t<ul class=\"wsite-menu\">\n\t\t{{#children}}{{> navigation\/flyout\/item}}{{\/children}}\n\t<\/ul>\n<\/div>\n","navigation\/flyout\/item":"<li {{#id}}id=\"{{id}}\"{{\/id}}\n\tclass=\"wsite-menu-subitem-wrap {{#is_current}}wsite-nav-current{{\/is_current}}\"\n\t>\n\t<a\n\t\t{{^nonclickable}}\n\t\t\t{{^nav_menu}}\n\t\t\t\thref=\"{{url}}\"\n\t\t\t{{\/nav_menu}}\n\t\t{{\/nonclickable}}\n\t\t{{#target}}\n\t\t\ttarget=\"{{target}}\"\n\t\t{{\/target}}\n\t\tclass=\"wsite-menu-subitem\"\n\t\t>\n\t\t<span class=\"wsite-menu-title\">\n\t\t\t{{{title_html}}}\n\t\t<\/span>{{#has_children}}<span class=\"wsite-menu-arrow\">&gt;<\/span>{{\/has_children}}\n\t<\/a>\n\t{{#has_children}}{{> navigation\/flyout\/list}}{{\/has_children}}\n<\/li>\n"},
			{}
		)
	}

</script>
		
		<script>
jQuery(document).ready(function($) {
		var displayTitle;
		var siteNameInURLHash = getURLParameter('name');
		var siteNameInSession = sessionStorage.getItem('userSiteName');

		if (siteNameInURLHash) {
			siteNameInSession = sessionStorage.setItem('userSiteName', siteNameInURLHash);
			displayTitle = siteNameInURLHash;
		} else if (siteNameInSession) {
			displayTitle = siteNameInSession;
		}

		if (displayTitle) {
			$('#wsite-title').text(displayTitle);
		}

    function getURLParameter(sParam) {
			 var sPageURL = decodeURIComponent(window.location.search.substring(1)),
		        sURLVariables = sPageURL.split('&'),
		        sParameterName,
		        i;

		    for (i = 0; i < sURLVariables.length; i++) {
		        sParameterName = sURLVariables[i].split('=');
		        if (sParameterName[0] === sParam) {
		            return sParameterName[1] === undefined ? true : sParameterName[1];
		        }
		    }
		}
});
</script>
	</head>
	<body class="header-page  wsite-page-index  full-width-body-off header-overlay-on alt-nav-off  wsite-theme-light">
	
	<div class="wrapper">

		<!--Import Header--> 
		<?php require_once('includes/header.php'); ?>	


		<div class="banner-wrap">
			<div class="wsite-elements wsite-not-footer wsite-header-elements">
				<div class="wsite-section-wrap">
					<div  class="wsite-section wsite-header-section wsite-section-bg-image" style="height: 689px;vertical-align: middle;background-image: url(images/banner-images/banner.jpg) ;background-repeat: no-repeat ;background-position: 50% 50% ;background-size: 100% ;background-color: transparent ;background-size: cover;" >
						<div class="wsite-section-content">
							<div class="container">
								<div class="banner">
									<div class="wsite-section-elements">
										<h2 class="wsite-content-title">
											<strong>
												<font color="#2a2a2a">&#8203;HEALTH &amp; WELLNESS</font>
											</strong>
										</h2>
										<div class="paragraph">
											<font color="#818181">
												<span style="font-weight:normal">
													<font size="4">For your overall well being </font>
												</span>
											</font>
										</div>
										<div style="text-align:center;">
											<div style="height: 10px; overflow: hidden;"></div>
											<a class="wsite-button wsite-button-small wsite-button-highlight" href="javascript:;" >
												<span class="wsite-button-inner">EXPLORE</span>
											</a>
											<div style="height: 10px; overflow: hidden;"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class=""></div>
					</div>
				</div>
			</div>
		</div>
		<div class="main-wrap">
			<div id="wsite-content" class="wsite-elements wsite-not-footer">
				<div class="wsite-section-wrap">
					<div class="wsite-section wsite-body-section wsite-section-bg-color wsite-background-2" style="height: auto;background-color: #ffffff;background-image: none;" >
						<div class="wsite-section-content">
							<div class="container">
								<div class="wsite-section-elements">
									<div class="wsite-spacer" style="height:44px;"></div>
									<h2 class="wsite-content-title" style="text-align:center;">
										<font color="#2a2a2a">OUR RANGE</font>
									</h2>
									<div class="wsite-spacer" style="height:32px;"></div>
									<div>
										<div class="wsite-multicol">
											<div class="wsite-multicol-table-wrap" style="margin:0 -5px;">
												<table class="wsite-multicol-table">
													<tbody class="wsite-multicol-tbody">
														<tr class="wsite-multicol-tr">
															<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 5px;">
																<div>
																	<div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
																		<a>
																			<img src="images/products/1.jpg" alt="Picture" style="width:314;max-width:100%" />
																		</a>
																		<div style="display:block;font-size:90%"></div>
																	</div>
																</div>
																<div>
																	<div class="wsite-image wsite-image-border-none " style="padding-top:0px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center">
																		<a>
																			<img src="images/products/2.jpg" alt="Picture" style="width:314;max-width:100%" />
																		</a>
																		<div style="display:block;font-size:90%"></div>
																	</div>
																</div>
															</td>
															<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 5px;">
																<div>
																	<div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
																		<a>
																			<img src="images/products/3.jpg" alt="Picture" style="width:313;max-width:100%" />
																		</a>
																		<div style="display:block;font-size:90%"></div>
																	</div>
																</div>
																<div class="wsite-spacer" style="height:28px;"></div>
																<h2 class="wsite-content-title" style="text-align:center;">
																	<font size="4" color="#ffffff">
																		<font size="4" color="#2a2a2a">
																			<strong>&nbsp;Exclusive</strong>
																		</font>
																		<br />
																	</font>
																</h2>
																<div>
																	<div style="height: 10px; overflow: hidden; width: 100%;"></div>
																	<hr class="styled-hr" style="width:100%;"></hr>
																	<div style="height: 20px; overflow: hidden; width: 100%;"></div>
																</div>
																<div class="paragraph" style="text-align:center;">
																	<span></span>
																	<span style="color:rgb(129, 129, 129)">Science and mindfulness complement each 
</span>
																	<br />
																	<span style="color:rgb(129, 129, 129)">other in helping people to  maintain their health and well-being.  </span>
																	<span></span>
																</div>
															</td>
															<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 5px;">
																<div>
																	<div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
																		<a>
																			<img src="images/products/4.jpg" alt="Picture" style="width:313;max-width:100%" />
																		</a>
																		<div style="display:block;font-size:90%"></div>
																	</div>
																</div>
																<div>
																	<div class="wsite-image wsite-image-border-none " style="padding-top:0px;padding-bottom:10px;margin-left:0px;margin-right:0px;text-align:center">
																		<a>
																			<img src="images/products/5.jpg" alt="Picture" style="width:313;max-width:100%" />
																		</a>
																		<div style="display:block;font-size:90%"></div>
																	</div>
																</div>
															</td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
									<div class="wsite-spacer" style="height:34px;"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="wsite-section-wrap">
					<div class="wsite-section wsite-body-section wsite-section-bg-image wsite-background-3" style="height: 405px;background-image: url(images/banner-images/philosophy.jpg) ;background-repeat: no-repeat ;background-position: 50% 50% ;background-size: 100% ;background-color: transparent ;background-size: cover;" >
						<div class="wsite-section-content">
							<div class="container">
								<div class="wsite-section-elements">
									<div class="wsite-spacer" style="height:50px;"></div>
									<h2 class="wsite-content-title" style="text-align:center;">
										<font color="#ffffff">OUR PHILOSOPHY</font>
									</h2>
									<div class="wsite-spacer" style="height:11px;"></div>
									<div class="paragraph" style="text-align:center;">
										<span style="color:rgb(255, 255, 255)"></span>
										<font size="4">
											<span style="color: rgb(255, 255, 255);"> To provide affordable healthcare to every Indian&nbsp;</span>
											
											
										</font>
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="wsite-section-wrap">
					<div class="wsite-section wsite-body-section wsite-section-bg-color wsite-background-4" style="height: 661px;background-color: #ffffff;background-image: none;" >
						<div class="wsite-section-content">
							<div class="container">
								<div class="wsite-section-elements">
									<div class="wsite-spacer" style="height:50px;"></div>
									<h2 class="wsite-content-title" style="text-align:center;">
										<font size="5" color="#2a2a2a">FEATURED PRODUCTS</font>
									</h2>
									<br/>
									<div class="commerce-elements-wrapper products__published"  data-page-id="571061010268150622" data-page-element-id="380519059732489478">
										<div class="pagination__overlay"></div>
										<div class="commerce-layout-wrapper">
											<div class="product-grid product-grid-columns--4 product-grid-layout--above">
												<div class="product-grid__item">
													<a class="product-grid__item-overlay" href="mask.php"></a>
													<div class="product-grid__content">
														<div class="product-grid__images">
															<div class="product-grid-image image-1 product-grid-image__default product-grid-image-aspect--1-1 js-default-img" style="background-image: url(images/products/mask/mask1.jpg)"></div>
															<div class="product-grid-image product-grid-image__slideshow image-1 product-grid-image-aspect--1-1 js-slideshow-img" style="background-image: url(images/products/mask/mask1.jpg);"></div>
														</div>
														<div class="product-grid__info" style="text-align:center">
															<h2 class="product-grid__title">
																<span class="product-grid-reset">Mask</span>
															</h2>
															<div class="product-grid__price paragraph">
																<!-- <span class="product-grid-reset">
																	$25.95
																</span> -->
															</div>
															<div class="product-grid__description paragraph">
																<span class="product-grid-reset product-grid__description--shortened"></span>
															</div>
															<div class="product-grid__button">
																<a href="mask.php" class="wsite-button wsite-button-small wsite-button-highlight">
																	<span class="wsite-button-inner">VIEW PRODUCT</span>
																</a>
															</div>
														</div>
													</div>
												</div>
												<div class="product-grid__item">
													<a class="product-grid__item-overlay" href="thermometer.php"></a>
													<div class="product-grid__content">
														<div class="product-grid__images">
															<div class="product-grid-image image-1 product-grid-image__default product-grid-image-aspect--1-1 js-default-img" style="background-image: url(images/products/ir/ir1.jpg)"></div>
															<div class="product-grid-image product-grid-image__slideshow image-1 product-grid-image-aspect--1-1 js-slideshow-img" style="background-image: url(images/products/ir/ir1.jpg);"></div>
														</div>
														<div class="product-grid__info" style="text-align:center">
															<h2 class="product-grid__title">
																<span class="product-grid-reset">Thermometer</span>
															</h2>
															<div class="product-grid__price paragraph">
																<!-- <span class="product-grid-reset">
																	$46.00
																</span> -->
															</div>
															<div class="product-grid__description paragraph">
																<span class="product-grid-reset product-grid__description--shortened"></span>
															</div>
															<div class="product-grid__button">
																<a href="thermometer.php" class="wsite-button wsite-button-small wsite-button-highlight">
																	<span class="wsite-button-inner">VIEW PRODUCT</span>
																</a>
															</div>
														</div>
													</div>
												</div>
												<div class="product-grid__item">
													<a class="product-grid__item-overlay" href="mask.php"></a>
													<div class="product-grid__content">
														<div class="product-grid__images">
															<div class="product-grid-image image-1 product-grid-image__default product-grid-image-aspect--1-1 js-default-img" style="background-image: url(images/products/mask/mask2.jpg)"></div>
															<div class="product-grid-image product-grid-image__slideshow image-1 product-grid-image-aspect--1-1 js-slideshow-img" style="background-image: url(images/products/mask/mask2.jpg);"></div>
														</div>
														<div class="product-grid__info" style="text-align:center">
															<h2 class="product-grid__title">
																<span class="product-grid-reset">Mask</span>
															</h2>
															<div class="product-grid__price paragraph">
																<!-- <span class="product-grid-reset">
																	$60.00
																</span> -->
															</div>
															<div class="product-grid__description paragraph">
																<span class="product-grid-reset product-grid__description--shortened"></span>
															</div>
															<div class="product-grid__button">
																<a href="mask.php" class="wsite-button wsite-button-small wsite-button-highlight">
																	<span class="wsite-button-inner">VIEW PRODUCT</span>
																</a>
															</div>
														</div>
													</div>
												</div>
												<div class="product-grid__item">
													<a class="product-grid__item-overlay" href="thermometer.php"></a>
													<div class="product-grid__content">
														<div class="product-grid__images">
															<div class="product-grid-image image-1 product-grid-image__default product-grid-image-aspect--1-1 js-default-img" style="background-image: url(images/products/ir/ir2.jpg)"></div>
															<div class="product-grid-image product-grid-image__slideshow image-1 product-grid-image-aspect--1-1 js-slideshow-img" style="background-image: url(images/products/ir/ir2.jpg);"></div>
														</div>
														<div class="product-grid__info" style="text-align:center">
															<h2 class="product-grid__title">
																<span class="product-grid-reset">Thermometer</span>
															</h2>
															<div class="product-grid__price paragraph">
																<!-- <span class="product-grid-reset">
																	$52.00
																</span> -->
															</div>
															<div class="product-grid__description paragraph">
																<span class="product-grid-reset product-grid__description--shortened"></span>
															</div>
															<div class="product-grid__button">
																<a href="thermometer.php" class="wsite-button wsite-button-small wsite-button-highlight">
																	<span class="wsite-button-inner">VIEW PRODUCT</span>
																</a>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="wsite-section-wrap">
					<div class="wsite-section wsite-body-section wsite-section-bg-image wsite-background-5" style="height: 333px;background-image: url(images/banner-images/grow.jpg) ;background-repeat: no-repeat ;background-position: 50% 50% ;background-size: 100% ;background-color: transparent ;background-size: cover;" >
						<div class="wsite-section-content">
							<div class="container">
								<div class="wsite-section-elements">
									<!-- <div>
										<div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
											<a>
												<img src="uploads/8/9/1/7/89179606/tag5f93.png?110" alt="Picture" style="width:110;max-width:100%" />
											</a>
											<div style="display:block;font-size:90%"></div>
										</div>
									</div> -->
									<div class="wsite-spacer" style="height:10px;"></div>
									<h2 class="wsite-content-title" style="text-align:center;">
										<strong style="color:rgb(255, 255, 255)">
											<font size="6">GROWING THROUGH RESEARCH</font>
										</strong>
									</h2>
									<br>
									<div class="paragraph" style="text-align:center;">
										<font color="#FFF" style="font-weight: bold">
											<font size="6">More Products Launching Soon</font>
										</font>
										<br />
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!--Import Bottom Navbar-->
				<?php //require_once('includes/homepage-bottom-menubar.php'); ?>
			</div>
		</div>

		<!--Import Footer-->
		<?php require_once('includes/footer.php'); ?>
	
  	</div><!-- /.wrapper -->

	<!--Import Nav Mobile-->
  	<?php require_once('includes/nav-mobile.php'); ?>

	<script type="text/javascript" src="js/custom72c5.js"></script>
	  
    <div id="customer-accounts-app"></div>
    	
</body>

</html>
