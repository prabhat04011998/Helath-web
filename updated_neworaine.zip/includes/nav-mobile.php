<div id="navMobile" class="nav mobile-nav">
    <a class="hamburger" aria-label="Menu" href="#"><span></span></a>
    <ul class="wsite-menu-default">
    		<li class="wsite-menu-item-wrap">
    			<a
    						href="index.php"
    				class="wsite-menu-item"
    				>
    				Home
    			</a>
    			
    		</li>
    		<li  class="wsite-menu-item-wrap">
    			<a
    						href="mask.php"
    				class="wsite-menu-item"
    				>
    				Masks
    			</a>
    			
    		</li>
    		<li  class="wsite-menu-item-wrap">
    			<a
    						href="thermometer.php"
    				class="wsite-menu-item"
    				>
    				IR Thermometer
    			</a>
    			
    		</li>
    		
    		<li id="pg393564071576403038" class="wsite-menu-item-wrap">
    			<a
    						href="about-us.php"
    				class="wsite-menu-item"
    				>
    				About
    			</a>
    			
    		</li>
    		
    		<li id="pg389626856345982332" class="wsite-menu-item-wrap">
    			<a
    						href="contact.php"
    				class="wsite-menu-item"
    				>
    				Contact
    			</a>
    			
    		</li>
    </ul>
  </div>